const button = document.querySelector("button");
const $text = document.querySelector("p");
const $input = document.querySelector("div");

//버튼 입력
button.addEventListener("click", function onButtonClick () {
  //횟수 카운트용
  i = 0
  //랜덤숫자 생성
  rado = Math.round(Math.random() * 1000)
  //랜덤숫자 분리
  rado1 = Math.floor(rado/100)
  rado2 = Math.floor(rado/10)%10
  rado3 = rado%10

  //0제외, 중복숫자 방지
  while (rado1 == 0 || rado2 == 0 || rado3 == 0 || rado1 == rado2 || rado1 == rado3 || rado3 == rado2)
  {
    //랜덤숫자 생성
    rado = Math.round(Math.random() * 1000)
    //랜덤숫자 분리
    rado1 = Math.floor(rado/100)
    rado2 = Math.floor(rado/10)%10
    rado3 = rado%10
  }

  //메시징
  $text.textContent = "랜덤숫자 생성완료";
  //입력창 생성
  $input.innerHTML = "<input 정답입력 type='number' id='num' onkeyup='enterkey()' placeholder='세자리숫자 입력후 엔터' >";
});

//엔터키 입력
function enterkey() {
  //횟수 제한
  if (i > 9)
    return $text.textContent = '실패하셨습니다.';
  //엔터키 키코드 == 13
	if (window.event.keyCode == 13) {
    //숫자입력
    num = Number(document.getElementById('num').value);
    //입력숫자 분리
    num1 = Math.floor(num/100)
    num2 = Math.floor(num/10)%10
    num3 = num%10
    //정답숫자
    strike = 0
    ball = 0
    //횟수 차감
    i +=1
////////////////////////////숫자야구 알고리즘////////////////////////////
    if (num>999 || num<100)
    {
      $text.textContent = "세자리가 아닙니다.";
      return;
    }
    if (num1 == rado1)
      strike += 1
    if (num2 == rado2)
      strike += 1
    if (num3 == rado3)
      strike += 1
    if (num1 == rado2)
      ball += 1
    if (num1 == rado3)
      ball += 1
    if (num2 == rado1)
      ball += 1
    if (num2 == rado3)
      ball += 1
    if (num3 == rado1)
      ball += 1
    if (num3 == rado2)
      ball += 1
  return $text.textContent = strike+'S'+ball+'B';
    }
}