const button = document.querySelector("button");
const $text = document.querySelector("p");
const $input = document.querySelector("div");

//버튼 입력
button.addEventListener("click", function onButtonClick () {
  //랜덤숫자 생성
  rado = Math.round(Math.random() * 1000)
  //랜덤숫자 분리
  rado1 = Math.floor(rado/100)
  rado2 = Math.floor(rado/10)%10
  rado3 = rado%10

  //0제외, 중복숫자 방지
  while (rado1 == 0 || rado2 == 0 || rado3 == 0 || rado1 == rado2 || rado1 == rado3 || rado3 == rado2)
  {
    //랜덤숫자 생성
    rado = Math.round(Math.random() * 1000)
    //랜덤숫자 분리
    rado1 = Math.floor(rado/100)
    rado2 = Math.floor(rado/10)%10
    rado3 = rado%10
  }
  
  //메시징
  $text.textContent = "랜덤숫자 생성완료";
  //입력창 생성
  $input.innerHTML = "<input type='number' id='num' onkeyup='enterkey()' size='4000'>";
});

//엔터키 입력
function enterkey() {
  //엔터키 키코드 == 13
	if (window.event.keyCode == 13) {
    //숫자입력
    num = Number(document.getElementById('num').value);
    //입력숫자 분리
    num1 = Math.floor(num/100)
    num2 = Math.floor(num/10)%10
    num3 = num%10
    //정답숫자
    strike = 0
    ball = 0
///////////////////////////숫자야구 알고리즘////////////////////////////
    if (num>999 || num<100)
    {
      $text.textContent = "세자리가 아닙니다.";
      return;
    }
    if (num1 == rado1)
      strike += 1
      console.log(rado1,rado2,rado3,num1,num2,num3)
      console.log(1,strike, ball)
    if (num2 == rado2)
      strike += 1
      console.log(2,strike, ball)
    if (num3 == rado3)
      strike += 1
      console.log(3,strike, ball)

    if (num1 == rado2)
      ball += 1
      console.log(4,strike, ball)
    if (num1 == rado3)
      ball += 1
      console.log(5,strike, ball)
    if (num2 == rado1)
      ball += 1
      console.log(6,strike, ball)
    if (num2 == rado3)
      ball += 1
      console.log(7,strike, ball)
    if (num3 == rado1)
      ball += 1
      console.log(8,strike, ball)
    if (num3 == rado2)
      ball += 1
      console.log(9,strike, ball)
  return $text.textContent = strike+'S'+ball+'B';
    }
}